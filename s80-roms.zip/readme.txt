File Description.

system_80_rom

This is the original System 80 "Black Label" ROM from my own machine 

system_80_trs80_printer_patch_rom

The System 80 addresses the printer differently to the TRS-80.  Since TRS-80 emulators emulate TRS-80 hardware, printing from them with a System 80 ROM in place doesn't work.  This ROM is for those (hard-core!) enthusiasts that want a fully workable emulator, but still want to see the visible manifestations of a System 80, in other words, the Ready? prompt, a SN error rather than an L3 one and the lack of a Radio Shack trademark on entering Level 2 BASIC.  I've simply changed the System 80 printer port calls in the ROM back to TRS-80 memory mapped ones. 

system_80_bluelabel_rom.  

This is the extended ROM from the later "Blue Label" Model (many thanks to Attila Grosz for supplying the ROM extensions).  The features of the extended ROM are activated in non-disk BASIC by typing "System" followed by <new line> then "/12288".  What you get is described in the 2nd revision of the User Manual.  The latest version of TRS32 accepts this ROM and allows the extended features to be activated.  I have not tried the ROM with any of the other emulators 

system_80_bluelabel_trs80_printer_patch_rom

Same as above, for the Blue Label ROM. 

System-80-MKII-rom

The extended ROM for the System 80 MK II business machine, with the numberic keypad. 

Trs80model1.rom

The original ROM for the TRS80 Model 1.

These ROMS will have to be renamed for use in most emulators.

Also present is the Exatron Stringy Floppy ROM for use in Matthew Reed's emulator.